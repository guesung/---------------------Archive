import Header from "./comp/Header";
import Nav from "./comp/Nav";
import Article from "./comp/Article";
function App() {
  const topics = [
    { id: 1, title: "html", body: "html is ..." },
    { id: 2, title: "css", body: "css is ..." },
    { id: 3, title: "javascript", body: "javascript is ..." },
    { id: 4, title: "react", body: "react is ..." },
  ];

  return (
    <div>
      <Header title="React"></Header>
      <Nav topics={topics}></Nav>
      <Article title="Welcome" body="React"></Article>

    </div>
  );
}
export default App;
