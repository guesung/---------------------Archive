function Recommend() {
  return <h1>Recommend Page</h1>;
}

export default Recommend;
