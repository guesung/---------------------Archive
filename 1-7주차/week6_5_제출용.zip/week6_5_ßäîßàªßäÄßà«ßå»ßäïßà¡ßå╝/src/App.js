// import './App.css'
import Footer from './comp/Footer';
import Header from './comp/Header';
import Main from './comp/Main';
function App() {

  return (
    <div>
  <Header />
      <Main />
<Footer/>
    </div>
  );
}
export default App;
