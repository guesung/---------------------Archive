const SearchBar = () => {
    return (
      <form>
        <input type="text" placeholder="상품영 입력" />
        <p>
          <input type="checkbox" /> <b>재고가 있는 상품</b>
        </p>
      </form>
    );
  };
  export default SearchBar ;
  