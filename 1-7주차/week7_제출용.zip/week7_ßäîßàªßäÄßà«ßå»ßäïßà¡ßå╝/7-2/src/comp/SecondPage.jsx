const SecondPage = () => {
  return (
    <div>
      {" "}
      <h3>This is the Second Page</h3>
    </div>
  );
};

export default SecondPage;
