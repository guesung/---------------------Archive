const FirstPage = () => {
  return (
    <div>
      {" "}
      <h3>This is the First Page</h3>{" "}
    </div>
  );
};
export default FirstPage;
