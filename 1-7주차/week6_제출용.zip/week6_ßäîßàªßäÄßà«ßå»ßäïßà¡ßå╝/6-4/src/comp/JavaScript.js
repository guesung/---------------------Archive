const JavaScript = () => {
  return (
    <main>
      <h2>JavaScript</h2>
      <ul>
        <li>
          Ecma International의 프로토타입 기반의 프로그래밍 언어로, 스크립트
          언어
        </li>
        <li>모든 웹 브라우저에 인터프리터가 내장되어 있다.</li>
        <li>오늘날 HTML, CSS와 함께 웹을 구성하는 요소 중 하나다.</li>
        <li>HTML이 웹 페이지의 기본 구조를 담당</li>
        <li>하고, CSS가 디자인을 담당한다면</li>
        <li>
          JavaScript는 클라이언트 단에서 웹 페이지가 동작하는 것을 담당한다.
        </li>
        <li>
          웹 페이지를 자동차에 비유하자면, HTML은 자동차의 뼈대, CSS는 자동차의
          외관, JavaScript는 자동차의 동력이라고 볼 수 있다.
        </li>
      </ul>
    </main>
  );
};

export default JavaScript;
