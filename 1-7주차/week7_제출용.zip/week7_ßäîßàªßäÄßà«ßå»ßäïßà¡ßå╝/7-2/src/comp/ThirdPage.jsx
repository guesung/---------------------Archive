const ThirdPage = () => {
  return (
    <div>
      {" "}
      <h3>This is the Third Page</h3>{" "}
    </div>
  );
};

export default ThirdPage;
