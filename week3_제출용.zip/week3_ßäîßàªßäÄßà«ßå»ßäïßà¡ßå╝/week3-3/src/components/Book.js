const Book = (props) => {
  const { title, author, description } = props;
  return (
    <article className="book">
      <h1>{title}</h1>
      <span>{author}</span>
      <p>{description}</p>
    </article>
  )
}
export default Book

