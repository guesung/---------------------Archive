export default function Header() {
  return (
    <header>
      <h1>
        <a href="index.html">WEB Programming</a>
      </h1>
    </header>
  );
}
