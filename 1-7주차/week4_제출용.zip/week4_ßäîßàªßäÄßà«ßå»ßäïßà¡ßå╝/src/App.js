import Productable from "./comp/Productable" ;
function App() {
  return (
    <div>
      <Productable/>
    </div>
  );
}
export default App;
