import Article from "./Component/Article";
import Footer from "./Component/Footer";
import Header from "./Component/Header";
import Nav from "./Component/Nav";
import ReactJs from "./Component/ReactJs";
import "./App.css";


export default function App() {
  return (
    <div>
      <Header />
      <div className="container">
        <Nav />
        <ReactJs />
        <Article />
      </div>
      <Footer />
    </div>
  );
}
