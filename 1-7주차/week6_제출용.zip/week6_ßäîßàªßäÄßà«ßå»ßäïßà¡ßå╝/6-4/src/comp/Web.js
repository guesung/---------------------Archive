function Web() {
  return (
    <main>
      <h3>WEB Programming</h3>
      <ul>
        <li> 웹 프로그래밍은 웹사이트 혹은 웹 페이지를 만드는 과정</li>
        <li> 웹 사이트 화면을 구성하는 것들을 만들어 내는 작업. </li>
        <li> 이 작업은 다양한 언어를 사용해 진행 </li>
        <li> 프런트엔드 언어 : HTML, CSS, JavaScript </li>
        <li> 백엔트 언어 : Python, Ruby, PHP, Java </li>
      </ul>
    </main>
  );
}

export default Web;
