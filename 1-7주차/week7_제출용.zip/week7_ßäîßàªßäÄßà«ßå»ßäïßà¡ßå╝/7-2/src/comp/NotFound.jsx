const NotFound = () => {
  return (
    <div>
            <h1>NotFound</h1>      <p>NotFound 404</p>   {" "}
    </div>
  );
};
export default NotFound;
