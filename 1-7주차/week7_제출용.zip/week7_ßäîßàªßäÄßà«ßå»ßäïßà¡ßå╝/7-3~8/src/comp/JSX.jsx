const JSX = () => {
  return (
    <div>
      <ul>
        <ul>
                    <li>코드가 간결</li>          <li>가독성이 향상</li>       
        </ul>
      </ul>

      <div>
                  <p>JSX 예시</p>          HTML 내에 JavaScript 프로그램이
        <img
          src="/image/jsx.gif"
          width="700px"
          height="400px"
          alt="jsx 예시"
        ></img>
      </div>
    </div>
  );
};
export default JSX;
