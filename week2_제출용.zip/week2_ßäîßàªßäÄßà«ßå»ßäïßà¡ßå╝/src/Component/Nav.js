export default function Nav() {
  return (
    <nav>
      <a href="html.html">HTML</a>
      <a href="css.html">CSS</a>
      <a href="js.html">JavaScript</a>
      <a href="react.html">ReactJs</a>
      <a href="nodejs.html">NodeJs</a>
    </nav>
  );
}
