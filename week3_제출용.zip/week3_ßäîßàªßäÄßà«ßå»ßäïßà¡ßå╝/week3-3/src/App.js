import BookList from "./components/BookList";
import './App.css'

function App() {
  return <BookList />;
}
export default App;
