function Nav(props) {
  const lis = []; // 빈 배열

  // 배열 Element 만큼 반복
  for (let i = 0; i < props.topics.length; i++) {
    let t = props.topics[i]; // i 번째 배열 Element
    lis.push(
      // 배열에 추가
      <li key={t.id}>
        <a href="/">{t.title}</a>
      </li>
    );
  }

  return (
    <nav>
      <ol>{lis}</ol>
    </nav>
  );
}

export default Nav;
